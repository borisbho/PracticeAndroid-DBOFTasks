package com.example.borisho.tasks;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;

public class DatabaseHelper extends SQLiteOpenHelper{

    public static final String DB_NAME = "task.db";
    public static final String TBL_NAME = "task_table";
    public static final String COLUMN1 = "ID";
    public static final String COLUMN2 = "TASK";
    public static final String COLUMN3 = "STATUS";
    public static final String COLUMN4 = "TIME";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String tableCreate = "CREATE TABLE " + TBL_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                " TASK TEXT, STATUS TEXT, TIME TEXT)";
        db.execSQL(tableCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF TABLE EXISTS " + TBL_NAME);
        onCreate(db);
    }
    public boolean addData(String task, String status, String time){
        SQLiteDatabase db = this.getWritableDatabase();
         ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN2, task );
        contentValues.put(COLUMN3,status);
        contentValues.put(COLUMN4,time);

        long result = db.insert(TBL_NAME,null,contentValues);

        if(result == -1){
            return false;
        }else{
            return true;
        }
    }
    public Cursor showData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TBL_NAME, null);
        return data;
    }
    public boolean updateData(String id, String task, String status, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN1,id);

        contentValues.put(COLUMN2,task );
        contentValues.put(COLUMN3,status);
        contentValues.put(COLUMN4,time);
        db.update(TBL_NAME, contentValues, "ID = ?" , new String[] {id});
        return true;
    }
    public Integer deleteData(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TBL_NAME, "ID = ?", new String[] {id});
    }}

