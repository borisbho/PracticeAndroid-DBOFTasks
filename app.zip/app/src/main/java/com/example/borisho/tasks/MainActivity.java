package com.example.borisho.tasks;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.Duration;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper taskDB;

    Button btnAddData, btnViewData, btnUpdate, btnDelete, btnStart, btnStop;
    EditText etTask, etID;
    CheckBox cbComplete;
    Chronometer cMeter;
    TextView textView, etStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        taskDB = new DatabaseHelper(this);
        etTask = (EditText) findViewById(R.id.etNewTask);
        etStatus = (TextView) findViewById(R.id.etNewStatus);
        btnAddData = (Button) findViewById(R.id.btnAddData);
        btnViewData = (Button) findViewById(R.id.btnViewData);
        btnUpdate = (Button) findViewById(R.id.btnNewUpdate);
        etID = (EditText) findViewById(R.id.etID);
        btnUpdate = (Button) findViewById(R.id.btnNewUpdate);
        btnDelete = (Button) findViewById(R.id.btnNewDelete);
        cbComplete = (CheckBox) findViewById(R.id.cbNewComplete);
        cMeter = (Chronometer) findViewById(R.id.cmNewMeter);
        btnStart = (Button) findViewById(R.id.btnNewStart);
        btnStop = (Button) findViewById(R.id.btnNewStop);
        textView = (TextView) findViewById(R.id.textView);


        AddData();
        ViewData();
        UpdateData();
        DeleteData();
        Start();
        Stop();
        getTime();

//        Intent intent=new Intent(MainActivity.this,ListDataActivity.class);
//        startActivityForResult(intent,1);
    }

    public void AddData() {
        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
//                long pause = SystemClock.elapsedRealtime() - cMeter.getBase();
//                long timeLapse = SystemClock.elapsedRealtime() - pause;
//                long timeWhenStopped = cMeter.getBase() - SystemClock.elapsedRealtime();

                if (cbComplete.isChecked()) {
                    etStatus.setText("COMPLETED");
                } else {
                    etStatus.setText("INCOMPLETE");
                }

                String task = etTask.getText().toString();
                String status = etStatus.getText().toString();
                int time = getTime();
                cMeter.setBase(SystemClock.elapsedRealtime()-time);
                boolean insertData = taskDB.addData(task, status, cMeter.getText().toString());

                if (insertData == true) {
                    Toast.makeText(MainActivity.this, "Data Successfully Inserted!", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(MainActivity.this, "Something went wrong :(.", Toast.LENGTH_LONG).show();
                }
                cMeter.setBase(SystemClock.elapsedRealtime());
                etStatus.setText("");
                etTask.setText("");

            }
        });
    }

    public void ViewData() {
        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });
    }

    public void UpdateData() {
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (cbComplete.isChecked()) {
                    etStatus.setText("COMPLETED");
                } else {
                    etStatus.setText("INCOMPLETE");
                }
                int temp = etID.getText().toString().length();
                if (temp > 0) {
                    cMeter.setBase(SystemClock.elapsedRealtime() - getTime());
                    boolean update = taskDB.updateData(etID.getText().toString(), etTask.getText().toString(),
                            etStatus.getText().toString(), cMeter.getText().toString()  );

                    if (update == true) {
                        Toast.makeText(MainActivity.this, "Successfully Updated Data!", Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(MainActivity.this, "Something Went Wrong :(.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You Must Enter An ID to Update :(.", Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    public void DeleteData() {
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = etID.getText().toString().length();
                if (temp > 0) {
                    Integer deleteRow = taskDB.deleteData(etID.getText().toString());
                    if (deleteRow > 0) {
                        Toast.makeText(MainActivity.this, "Successfully Deleted The Data!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Something went wrong :(.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You Must Enter An ID to Delete :(.", Toast.LENGTH_LONG).show();
                }
                etTask.setText("");
                etStatus.setText("");
                etID.setText("");
                cbComplete.setChecked(false);
            }
        });
    }

    public void Start() {
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cMeter.setBase(SystemClock.elapsedRealtime());

                cMeter.start();
                Log.d("FORMAT: ", Long.toString(SystemClock.elapsedRealtime() - getTime()));
            }
        });
    }

    public void Stop() {
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cMeter.stop();

            }
        });
    }

    public int getTime() {
        int stoppedMilliseconds = 0;

        String chronoText = cMeter.getText().toString();
        String array[] = chronoText.split(":");
        if (array.length == 2) {
            stoppedMilliseconds = Integer.parseInt(array[0]) * 60 * 1000
                    + Integer.parseInt(array[1]) * 1000;
        } else if (array.length == 3) {
            stoppedMilliseconds = Integer.parseInt(array[0]) * 60 * 60 * 1000
                    + Integer.parseInt(array[1]) * 60 * 1000
                    + Integer.parseInt(array[2]) * 1000;
        }

        // cMeter.setBase(SystemClock.elapsedRealtime() - stoppedMilliseconds);

        return stoppedMilliseconds;
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == 1) {
//            if (resultCode == RESULT_OK) {
//
//                // get String data from Intent
//                String returnString = data.getStringExtra("Task");
//
//                // set text view with string
//                etTask.setText(returnString);
//            }
//        }
//
//
//    }
}
