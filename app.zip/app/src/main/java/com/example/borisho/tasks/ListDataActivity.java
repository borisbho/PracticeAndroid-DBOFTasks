package com.example.borisho.tasks;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.util.ArrayList;


public class ListDataActivity extends AppCompatActivity {

    public ArrayList<String> ok = new ArrayList<>();

    DatabaseHelper taskDB;
    private ListView mListView;
    EditText editText;
    Chronometer cm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);
        mListView = (ListView) findViewById(R.id.ListView);
        editText = (EditText) findViewById(R.id.etNewTask);
        taskDB = new DatabaseHelper(this);
        populateList();
    }

    private void populateList() {

        Cursor data = taskDB.showData();
        if (data.getCount() == 0) {
            return;
        }
         while (data.moveToNext()) {

            ok.add("ID: " + data.getString(0) + "\n" +
                    "TASK: " + data.getString(1) + "\n" +
                    "STATUS: " + data.getString(2) + "\n" +
                    "TIME: " + data.getString(3));

        }
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ok);
        mListView.setAdapter(adapter);
    }
//    public void onItemClick(){
//        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//                Object[] classes = ok.toArray();
//                Intent intent = new Intent(ListDataActivity.this, MainActivity.class);
//                intent.putExtra("Task", (String)classes[position] );
//                setResult(RESULT_OK,intent);
//                finish();
//
//             }
//        });
    }
